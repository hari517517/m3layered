﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using SMS.Entity;
using SMS.Exception;
using SMS.BL;

namespace SMS.PL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        public void Clear()
        {
            txtStudCode.Text = "";
            txtStudName.Text = "";
            txtDeptCode.Text = "";
            txtStudDob.Text = "";
            txtStudAddress.Text = "";
            btnUpdate.IsEnabled = false;
            btnDelete.IsEnabled = false;
            txtStudCode.IsReadOnly = false;
            txtStudName.IsReadOnly = false;
            txtStudDob.IsEnabled = true;
        }

        public void Show()
        {
            try 
            {
                List<Student> studList = StudentValidation.RetrieveStudent();

                if (studList == null || studList.Count <= 0)
                    throw new StudentException("Records not available");
                else
                {
                    dgStudent.DataContext = studList;
                }
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            Show();
        }

        private void btnInsert_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                Student stud = new Student();

                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtStudName.Text;
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtStudDob.Text);
                stud.Address = txtStudAddress.Text;

                int recordsAffected = StudentValidation.InsertStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record inserted successfully");
                    Show();
                    Clear();
                }
                else
                    throw new StudentException("Record not inserted");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                int studCode = Convert.ToInt32(txtStudCode.Text);

                Student stud = StudentValidation.SearchStudent(studCode);

                if (stud != null)
                {
                    txtStudCode.Text = stud.StudCode.ToString();
                    txtStudName.Text = stud.StudName;
                    txtDeptCode.Text = stud.DeptCode.ToString();
                    txtStudDob.Text = stud.DOB.ToString();
                    txtStudAddress.Text = stud.Address;

                    btnUpdate.IsEnabled = true;
                    btnDelete.IsEnabled = true;
                    txtStudCode.IsReadOnly = true;
                    txtStudName.IsReadOnly = true;
                    txtStudDob.IsEnabled = false;
                }
                else
                    throw new StudentException("Student record not found");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                Student stud = new Student();

                stud.StudCode = Convert.ToInt32(txtStudCode.Text);
                stud.StudName = txtStudName.Text;
                stud.DeptCode = Convert.ToInt32(txtDeptCode.Text);
                stud.DOB = Convert.ToDateTime(txtStudDob.Text);
                stud.Address = txtStudAddress.Text;

                int recordsAffected = StudentValidation.UpdateStudent(stud);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully");
                    Show();
                    Clear();
                }
                else
                    throw new StudentException("Record not updated");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {
            try 
            {
                int studCode = Convert.ToInt32(txtStudCode.Text);

                int recordsAffected = StudentValidation.DeleteStudent(studCode);

                if (recordsAffected > 0)
                {
                    MessageBox.Show("Record Deleted Successfully");
                    Show();
                    Clear();
                }
                else
                    throw new StudentException("Record not deleted");
            }
            catch (StudentException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SystemException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnCount_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnClear_Click(object sender, RoutedEventArgs e)
        {
            Clear();
        }
    }
}
