﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS.Exception
{
    /// <summary>
    /// Employee ID :
    /// Employee Name :
    /// Description : The class for raising Student spcific exceptions
    /// Date of Creation : 
    /// </summary>
    public class StudentException : ApplicationException
    {
        //Default constructor
        public StudentException()
            : base()
        { }

        //Parameterized constructor with message parameter
        public StudentException(string message)
            : base(message)
        { }
    }
}
