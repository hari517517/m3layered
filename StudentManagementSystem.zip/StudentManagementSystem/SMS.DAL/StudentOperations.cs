﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS.Entity;           //Reference to Entity library
using SMS.Exception;        //Reference to Exeption Library
using System.Data.SqlClient;

namespace SMS.DAL
{
    public class StudentOperations
    {
        //Function to insert student record in database
        public static int InsertStudent(Student stud)
        {
            int recordsAffected = 0;

            try 
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_InsertStudent";
                
                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", stud.StudCode);
                cmd.Parameters.AddWithValue("@Stud_Name", stud.StudName);
                cmd.Parameters.AddWithValue("@Dept_Code", stud.DeptCode);
                cmd.Parameters.AddWithValue("@DOB", stud.DOB);
                cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to update student record from database
        public static int UpdateStudent(Student stud)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_UpdateStudent";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", stud.StudCode);
                cmd.Parameters.AddWithValue("@Dept_Code", stud.DeptCode);
                cmd.Parameters.AddWithValue("@Address", stud.Address);

                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to delete student record from database
        public static int DeleteStudent(int studCode)
        {
            int recordsAffected = 0;

            try
            {
                //Creating command object
                SqlCommand cmd = DataConnection.GenerateCommand();
                //Assigning command text
                cmd.CommandText = "usp_DeleteStudent";

                //Adding parameters to command
                cmd.Parameters.AddWithValue("@Stud_Code", studCode);
                
                //Executing command
                cmd.Connection.Open();
                recordsAffected = cmd.ExecuteNonQuery();
                cmd.Connection.Close();
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return recordsAffected;
        }

        //Function to search student record based on Student Code
        public static Student SearchStudent(int studCode)
        {
            Student stud = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "usp_SearchStudent";
                cmd.Parameters.AddWithValue("@Stud_Code", studCode);

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    stud = new Student();
                    dr.Read();
                    stud.StudCode = (int)dr["Student_Code"];
                    stud.StudName = dr["Student_name"].ToString();
                    stud.DeptCode = (int)dr["Dept_Code"];
                    stud.DOB = Convert.ToDateTime(dr["Student_dob"]);
                    stud.Address = dr["Student_Address"].ToString();
                }
                else
                {
                    throw new StudentException("Record not found");
                }
                cmd.Connection.Close();
            }
            catch(StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch(SystemException ex)
            {
                throw ex;
            }

            return stud;
        }

        //Function to retrieve all student record
        public static List<Student> RetrieveStudent()
        {
            List<Student> studList = null;

            try 
            {
                SqlCommand cmd = DataConnection.GenerateCommand();
                cmd.CommandText = "usp_DisplayStudent";

                cmd.Connection.Open();
                SqlDataReader dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    studList = new List<Student>();
                    while (dr.Read())
                    {
                        Student stud = new Student();

                        stud.StudCode = (int)dr["Student_Code"];
                        stud.StudName = dr["Student_name"].ToString();
                        stud.DeptCode = (int)dr["Dept_Code"];
                        stud.DOB = Convert.ToDateTime(dr["Student_dob"]);
                        stud.Address = dr["Student_Address"].ToString();

                        studList.Add(stud);
                    }
                }
                else
                    throw new StudentException("Record not available");
                cmd.Connection.Close();
            }
            catch (StudentException ex)
            {
                throw ex;
            }
            catch (SqlException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studList;
        }
    }
}
